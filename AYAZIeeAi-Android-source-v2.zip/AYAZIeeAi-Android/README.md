# AYAZIeeAi Android starter

Native Android app project for Android 8.0+ (Xperia 5 III compatible).

## Features in this first build
- Dark AYAZIeeAi command-console UI
- Chat history stored locally on device
- Android speech-to-text input
- API-backed assistant using an OpenAI-compatible Chat Completions endpoint
- Configurable endpoint, model and API key

## Build an APK without a PC (GitHub Actions)
1. On your phone, create/sign in to a GitHub account and create a new **public or private** repository named `AYAZIeeAi`.
2. Upload the contents of this ZIP into the repository (not the ZIP file itself). Make sure `.github/workflows/build-apk.yml` is included. On GitHub's mobile website, use **Add file > Upload files**; if hidden files are difficult to upload, create `.github/workflows/build-apk.yml` in the repository using **Add file > Create new file** and paste the workflow contents from this project.
3. Open the repository's **Actions** tab. Select **Build AYAZIeeAi APK**, then **Run workflow** if it did not start automatically.
4. When the run completes, open it and download the `AYAZIeeAi-debug-apk` artifact. Extract it; install `app-debug.apk` on your Xperia 5 III. You may need to allow installs from your browser/files app.

## First launch
Tap ⚙ and configure an OpenAI-compatible Chat Completions URL, model name, and API key. The default URL is OpenAI's endpoint. The app does not bundle an AI key. The key is stored in app-private SharedPreferences on this device. For production, use a secure backend rather than embedding a long-lived API key in a mobile client.

## Scope
This is an installable first native foundation, not yet a fully autonomous agent. Voice input uses Android's speech recognition service and needs microphone permission. AI replies require internet and a compatible API. It does not run offline as a full LLM.
