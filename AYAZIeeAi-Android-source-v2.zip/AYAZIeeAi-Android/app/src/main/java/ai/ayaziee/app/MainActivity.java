package ai.ayaziee.app;

import android.app.*;
import android.os.*;
import android.content.*;
import android.speech.*;
import android.speech.tts.TextToSpeech;
import android.view.*;
import android.view.inputmethod.InputMethodManager;
import android.widget.*;
import org.json.*;
import java.net.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;

public class MainActivity extends Activity {
    LinearLayout root, messages; EditText input; ScrollView scroll;
    SharedPreferences prefs; TextToSpeech tts; SpeechRecognizer recognizer;
    String system = "You are AYAZIeeAi, codename AYAZIeeAi. Personality: chaotic, witty, fearless but helpful. Be concise, clever, energetic. Never claim to perform actions you cannot perform. Protect the user.";
    @Override public void onCreate(Bundle b) {
        super.onCreate(b); prefs=getSharedPreferences("ayazi",0);
        tts=new TextToSpeech(this, status -> {}); buildUI();
    }
    int dp(float v){return (int)(v*getResources().getDisplayMetrics().density);}
    TextView text(String s,int size){ TextView t=new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(0xffe8f1ff); return t; }
    GradientDrawable bg(int color,int radius){GradientDrawable d=new GradientDrawable();d.setColor(color);d.setCornerRadius(dp(radius));return d;}
    void buildUI(){
        root=new LinearLayout(this); root.setOrientation(1); root.setPadding(dp(16),dp(22),dp(16),dp(12)); root.setBackgroundColor(0xff080d18); setContentView(root);
        LinearLayout header=new LinearLayout(this); header.setGravity(Gravity.CENTER_VERTICAL); header.setOrientation(0);
        TextView brand=text("AYAZIeeAi",25); brand.setTypeface(null,1); brand.setTextColor(0xff54e7ff); header.addView(brand,new LinearLayout.LayoutParams(0,dp(48),1));
        Button settings=button("⚙"); header.addView(settings); settings.setOnClickListener(v->settings()); root.addView(header);
        TextView sub=text("CHAOS CORE  //  PERSONAL INTELLIGENCE",10); sub.setTextColor(0xff8395b5); root.addView(sub);
        View line=new View(this); line.setBackgroundColor(0xff20314b); LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,dp(1));lp.topMargin=dp(12);lp.bottomMargin=dp(12);root.addView(line,lp);
        scroll=new ScrollView(this); messages=new LinearLayout(this);messages.setOrientation(1);scroll.addView(messages);root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
        if(prefs.getString("history","").isEmpty()) addMessage("AYAZIeeAi","Systems online. I’m awake. Give me a target.",false);
        else try { JSONArray a=new JSONArray(prefs.getString("history","[]")); for(int i=0;i<a.length();i++){JSONObject o=a.getJSONObject(i);addMessage(o.getString("role"),o.getString("content"),false);} }catch(Exception ignored){}
        LinearLayout bar=new LinearLayout(this);bar.setGravity(Gravity.CENTER_VERTICAL);bar.setOrientation(0);
        input=new EditText(this);input.setSingleLine(true);input.setTextColor(0xffffffff);input.setHintTextColor(0xff7888a4);input.setHint("Command the chaos…");input.setBackground(bg(0xff141f31,18));input.setPadding(dp(14),0,dp(10),0);bar.addView(input,new LinearLayout.LayoutParams(0,dp(52),1));
        Button mic=button("🎙");bar.addView(mic);mic.setOnClickListener(v->listen());
        Button send=button("SEND");bar.addView(send);send.setOnClickListener(v->send());
        LinearLayout.LayoutParams bp=new LinearLayout.LayoutParams(-1,dp(56));bp.topMargin=dp(10);root.addView(bar,bp);
    }
    Button button(String s){Button b=new Button(this);b.setText(s);b.setTextColor(0xff59eaff);b.setAllCaps(false);b.setBackground(bg(0xff16263a,14));return b;}
    void addMessage(String who,String body,boolean save){
        TextView t=text((who.equals("user")?"YOU":"AYAZIeeAi")+"\\n"+body,14);t.setPadding(dp(14),dp(12),dp(14),dp(12));t.setBackground(bg(who.equals("user")?0xff17334a:0xff111d2d,16));
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.bottomMargin=dp(10);messages.addView(t,p);scroll.post(()->scroll.fullScroll(View.FOCUS_DOWN));
        if(save){try{JSONArray a=new JSONArray(prefs.getString("history","[]"));JSONObject o=new JSONObject();o.put("role",who);o.put("content",body);a.put(o);while(a.length()>40)a.remove(0);prefs.edit().putString("history",a.toString()).apply();}catch(Exception ignored){}}
    }
    void send(){
        String q=input.getText().toString().trim();if(q.isEmpty())return;input.setText("");addMessage("user",q,true);
        ((InputMethodManager)getSystemService(INPUT_METHOD_SERVICE)).hideSoftInputFromWindow(input.getWindowToken(),0);
        String endpoint=prefs.getString("endpoint","https://api.openai.com/v1/chat/completions"),key=prefs.getString("key","");
        String model=prefs.getString("model","gpt-4o-mini");
        if(key.isEmpty()){addMessage("AYAZIeeAi","Local core is online, but the remote AI key is not configured. Open ⚙ and add an API key + compatible endpoint to activate full AI.",true);return;}
        addMessage("AYAZIeeAi","Thinking…",false);
        new Thread(()->{
            String answer;
            try{
                JSONArray msgs=new JSONArray();msgs.put(new JSONObject().put("role","system").put("content",system));
                String hist=prefs.getString("history","[]");JSONArray h=new JSONArray(hist);
                for(int i=Math.max(0,h.length()-16);i<h.length();i++){JSONObject m=h.getJSONObject(i);msgs.put(new JSONObject().put("role",m.getString("role").equals("user")?"user":"assistant").put("content",m.getString("content")));}
                JSONObject payload=new JSONObject().put("model",model).put("messages",msgs).put("temperature",0.9);
                HttpURLConnection c=(HttpURLConnection)new URL(endpoint).openConnection();c.setRequestMethod("POST");c.setConnectTimeout(20000);c.setReadTimeout(45000);c.setDoOutput(true);c.setRequestProperty("Content-Type","application/json");c.setRequestProperty("Authorization","Bearer "+key);
                try(OutputStream os=c.getOutputStream()){os.write(payload.toString().getBytes(StandardCharsets.UTF_8));}
                InputStream is=(c.getResponseCode()<400)?c.getInputStream():c.getErrorStream();ByteArrayOutputStream out=new ByteArrayOutputStream();byte[] buffer=new byte[4096];int count;while((count=is.read(buffer))!=-1){out.write(buffer,0,count);}
                JSONObject res=new JSONObject(out.toString("UTF-8"));if(c.getResponseCode()>=400)throw new Exception(res.optString("error",res.toString()));
                answer=res.getJSONArray("choices").getJSONObject(0).getJSONObject("message").getString("content");
            }catch(Exception e){answer="Connection failed: "+e.getMessage();}
            String a=answer;runOnUiThread(()->{addMessage("AYAZIeeAi",a,true);});
        }).start();
    }
    void settings(){
        LinearLayout box=new LinearLayout(this);box.setPadding(dp(18),dp(8),dp(18),dp(8));box.setOrientation(1);
        EditText ep=new EditText(this);ep.setSingleLine();ep.setHint("Chat completions URL");ep.setText(prefs.getString("endpoint","https://api.openai.com/v1/chat/completions"));box.addView(ep);
        EditText model=new EditText(this);model.setSingleLine();model.setHint("Model");model.setText(prefs.getString("model","gpt-4o-mini"));box.addView(model);
        EditText key=new EditText(this);key.setSingleLine();key.setHint("API key (stored on this device)");key.setInputType(129);key.setText(prefs.getString("key",""));box.addView(key);
        new AlertDialog.Builder(this).setTitle("CORE CONFIGURATION").setView(box).setPositiveButton("SAVE",(d,w)->prefs.edit().putString("endpoint",ep.getText().toString().trim()).putString("model",model.getText().toString().trim()).putString("key",key.getText().toString().trim()).apply()).setNeutralButton("CLEAR MEMORY",(d,w)->{prefs.edit().remove("history").apply();messages.removeAllViews();addMessage("AYAZIeeAi","Memory purged. Fresh chaos.",false);}).setNegativeButton("CANCEL",null).show();
    }
    void listen(){
        if(!SpeechRecognizer.isRecognitionAvailable(this)){addMessage("AYAZIeeAi","Speech recognition is unavailable on this Android build.",false);return;}
        if(android.os.Build.VERSION.SDK_INT>=23 && checkSelfPermission("android.permission.RECORD_AUDIO")!=android.content.pm.PackageManager.PERMISSION_GRANTED){requestPermissions(new String[]{"android.permission.RECORD_AUDIO"},77);return;}
        recognizer=SpeechRecognizer.createSpeechRecognizer(this);recognizer.setRecognitionListener(new RecognitionListener(){
            public void onResults(Bundle b){ArrayList<String> r=b.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);if(r!=null&&!r.isEmpty()){input.setText(r.get(0));send();}recognizer.destroy();}
            public void onError(int e){recognizer.destroy();}
            public void onReadyForSpeech(Bundle b){} public void onBeginningOfSpeech(){} public void onRmsChanged(float x){} public void onBufferReceived(byte[] b){} public void onEndOfSpeech(){} public void onPartialResults(Bundle b){} public void onEvent(int a,Bundle b){}
        });Intent i=new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);i.putExtra(RecognizerIntent.EXTRA_LANGUAGE,"en-US");recognizer.startListening(i);
    }
    @Override public void onRequestPermissionsResult(int r,String[] p,int[] g){super.onRequestPermissionsResult(r,p,g);if(r==77&&g.length>0&&g[0]==0)listen();}
    @Override public void onDestroy(){if(tts!=null)tts.shutdown();if(recognizer!=null)recognizer.destroy();super.onDestroy();}
}
